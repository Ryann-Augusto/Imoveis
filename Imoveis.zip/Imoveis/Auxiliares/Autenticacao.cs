﻿using Imoveis.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace Imoveis.Auxiliares
{
    public class Autenticacao
    {
        
    }
}